package com.jpa.main.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.jpa.main.model.Employee;
import com.jpa.main.service.EmployeeServiceInterface;

@RestController
public class EmployeeController {
@Autowired
EmployeeServiceInterface service;
@PostMapping("saveEmployee")
public ResponseEntity<String> saveEmployee(@RequestBody Employee emp) {
	service.saveEmployee(emp);
	return new ResponseEntity<String>("saved successfully", HttpStatus.CREATED);
}
@GetMapping("/fetchEmployee")
@ResponseBody
public ResponseEntity<List<Employee>> fetchEmployee() {
	List<Employee> emp = service.fetchEmployee();
	if(emp.size()==0) {
		return new ResponseEntity<>(HttpStatus.NO_CONTENT) ;

	}
	return new ResponseEntity<>(emp,HttpStatus.OK) ;
}
}