package com.jpa.main.service;

import java.util.List;

import com.jpa.main.model.Employee;

public interface EmployeeServiceInterface {

	void saveEmployee(Employee emp);

	List<Employee> fetchEmployee();

}
