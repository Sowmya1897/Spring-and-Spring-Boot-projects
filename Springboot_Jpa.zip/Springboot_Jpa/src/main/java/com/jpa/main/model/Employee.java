package com.jpa.main.model;

import javax.persistence.*;

@Entity
@Table(name="employee")
public class Employee {
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
@Column(name="eid")
private int eid;
@Column(name="name")
private String name;
@Column(name="email")
private String email;
@Column(name="address")
private String address;
public int getEid() {
	return eid;
}
public void setEid(int eid) {
	this.eid = eid;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public Employee(int eid, String name, String email, String address) {
	super();
	this.eid = eid;
	this.name = name;
	this.email = email;
	this.address = address;
}
public Employee() {
	super();
	// TODO Auto-generated constructor stub
}
@Override
public String toString() {
	return "Employee [eid=" + eid + ", name=" + name + ", email=" + email + ", address=" + address + "]";
}


}
