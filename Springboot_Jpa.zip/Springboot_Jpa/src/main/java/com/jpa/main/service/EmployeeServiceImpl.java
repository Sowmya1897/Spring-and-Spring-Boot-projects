package com.jpa.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jpa.main.model.Employee;
import com.jpa.main.repository.EmployeeRepository;
@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeServiceInterface {
@Autowired 
EmployeeRepository repository;
	
	public void saveEmployee(Employee emp) {
		repository.save(emp);
		
	}
	
	public List<Employee> fetchEmployee() {
		return repository.findAll();
	}

}
