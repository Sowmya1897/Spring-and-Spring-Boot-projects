package com.joincolumn;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;
import javax.persistence.GenerationType;

@Entity
@Table(name="Employee")
public class Employee {
	@Id
	@GeneratedValue(strategy=GenerationType.TABLE)
	@Column(name="eid")
private int eid;
	@Column(name="firstName")
private String firstName;
	@Column(name="lastName")
private String lastName;
	
	@ManyToOne
	private CompanyList company;
	
public int getEid() {
	return eid;
}
public void setEid(int eid) {
	this.eid = eid;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public CompanyList getCompany() {
	return company;
}
public void setCompany(CompanyList company) {
	this.company = company;
}
@Override
public String toString() {
	return "Employee [eid=" + eid + ", firstName=" + firstName + ", lastName=" + lastName + ", company=" + company
			+ "]";
}
public Employee() {
	super();
	// TODO Auto-generated constructor stub
}

}
