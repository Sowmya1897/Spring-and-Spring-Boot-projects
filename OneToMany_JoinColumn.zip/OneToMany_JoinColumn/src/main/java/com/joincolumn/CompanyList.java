package com.joincolumn;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

@Entity
@Table(name="CompanyList")
public class CompanyList {
	@Id
	@GeneratedValue(strategy=GenerationType.TABLE)
	@Column(name="cid")
private int cid;
	@Column(name="companyName")
private String companyName;
	
	 @OneToMany(cascade=CascadeType.ALL)
	    @JoinColumn(name="comp_id")
	private List<Employee> employee = new ArrayList<Employee>();
@Override
	public String toString() {
		return "CompanyList [cid=" + cid + ", companyName=" + companyName + ", employee=" + employee + "]";
	}
public int getCid() {
	return cid;
}
public void setCid(int cid) {
	this.cid = cid;
}
public String getCompanyName() {
	return companyName;
}
public void setCompanyName(String companyName) {
	this.companyName = companyName;
}
public List<Employee> getEmployee() {
	return employee;
}
public void setEmployee(List<Employee> employee) {
	this.employee = employee;
}
public CompanyList() {
	super();
	// TODO Auto-generated constructor stub
}

}
