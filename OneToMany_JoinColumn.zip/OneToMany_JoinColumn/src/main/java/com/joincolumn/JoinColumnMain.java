package com.joincolumn;

import java.util.ArrayList;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class JoinColumnMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sessionFactory = cfg.buildSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		
		    Employee e1 = new Employee();
			e1.setFirstName("Sowmya");
			e1.setLastName("Ramidi");
					
			 Employee e2 = new Employee();
			 e2.setFirstName("Anusha");
			 e2.setLastName("Gadhe");
			
			 Employee e3 = new Employee();
			 e3.setFirstName("Neelima");
			 e3.setLastName("Annabattula");
			 
			 Employee e4 = new Employee();
			 e4.setFirstName("Shirisha");
			 e4.setLastName("Kanigi");
			
			ArrayList<Employee> list1 = new ArrayList<Employee>();
			list1.add(e1);
			list1.add(e3);
			
			ArrayList<Employee> list2 = new ArrayList<Employee>();
			list2.add(e2);
			list2.add(e4);
			
		CompanyList comp1 = new CompanyList();
		comp1.setCompanyName("Hcl");
		comp1.setEmployee(list1);
		
		
		CompanyList comp2 = new CompanyList();
		comp2.setCompanyName("Wipro");
		comp2.setEmployee(list2);
		
		session.persist(comp1);
		session.persist(comp2);
		tx.commit();
		session.close();
		System.out.println("Company Employees are filled successfully");
	}

}
