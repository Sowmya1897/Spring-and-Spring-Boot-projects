package com.postconstruct.main;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.postconstruct.main.model.EmployeeInfo;
import com.postconstruct.main.repository.EmployeeRepository;

@SpringBootApplication
public class SpringbootPostConstructApplication implements CommandLineRunner{
	
	Logger logger =LoggerFactory.getLogger(SpringbootPostConstructApplication.class);
	
	@Autowired
	EmployeeRepository repository;
	
	@Autowired
	EmployeeInfo empInfo;
	
	public static void main(String[] args) {
		SpringApplication.run(SpringbootPostConstructApplication.class, args);
	}
	
	@PostConstruct
	public void saveEmployee() {
		List ls = Stream.of(new EmployeeInfo("Likitha", 26,"likitha@gmail.com"), new EmployeeInfo("soni", 30,"soni@gmail.com"))
				.collect(Collectors.toList());
		repository.saveAll(ls);
	}

	@Override
	public void run(String... args) throws Exception {
	logger.info(empInfo.getName());
	logger.info(empInfo.getEmail());
	}
}
