package com.in28minutes.springboot_profile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootProfileApplicationTests {

	@Test
	void contextLoads() {
	}

}
