package com.in28minutes.springboot_profile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootProfileApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootProfileApplication.class, args);
	}

}
