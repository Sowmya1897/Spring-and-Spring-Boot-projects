package com.demo.hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class HibernateDemo {
public static void main(String[] args) {
	Configuration cfg = new Configuration();
	cfg.configure("hibernate.cfg.xml");
	SessionFactory sessionFactory = cfg.buildSessionFactory();
		    Session session=sessionFactory.openSession();
		    //Transaction tx= session.beginTransaction();
		    //Employee emp=new Employee(12,"revathi","g","chennai","revathig@hcl.com");
		    //session.save(emp);
		    //tx.commit();
		    Employee emp = (Employee)session.get(Employee.class, 1);//select * from tblemp where id=1;
		    System.out.println(emp);
		    
		    Employee emp1 = (Employee)session.load(Employee.class, 2);//select * from tblemp where id=1;
		    System.out.println(emp1);
		    
		    System.out.println("Success");
}
}
