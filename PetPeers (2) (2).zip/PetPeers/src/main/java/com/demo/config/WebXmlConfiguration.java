package com.demo.config;

import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

public class WebXmlConfiguration extends AbstractAnnotationConfigDispatcherServletInitializer {
	
protected Class<?>[] getRootConfigClasses() {
		
		return null;
	}

	
protected Class<?>[] getServletConfigClasses() {
        
        return new Class[]{PetConfig.class};
    }

 

    
    protected String[] getServletMappings() {
        
        return new String[]{"/"};
    }
}
