package com.demo.service;

import java.util.List;

import com.demo.model.Pet;
import com.demo.model.User;

public interface PetService {
	
	User saveUser(User user);
	List<Pet> getAllPets();
	List<Pet> getMyPets(int userId);
	void savePet(Pet pets);
	User authenticateUser(String name, String passwd);
	void buyPet(int petId, int userId);

}
