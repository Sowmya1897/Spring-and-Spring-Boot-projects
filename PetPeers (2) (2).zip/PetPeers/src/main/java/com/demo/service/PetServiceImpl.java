package com.demo.service;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.demo.dao.PetDao;
import com.demo.dao.PetDaoImpl;
import com.demo.model.Pet;
import com.demo.model.User;

@Service
@Transactional
public class PetServiceImpl implements PetService {
	@Autowired
	PetDao petDao;
	
	
	public void setPetDao(PetDaoImpl petDaoImpl) {
		this.petDao=petDao;
	}
	
	public PetServiceImpl(PetDao petDao) {
		super();
		this.petDao=petDao;
	}
	
	

	
	public User saveUser(User user) {
		
		return petDao.saveUser(user);
	}

	
	public List<Pet> getAllPets() {
		
		return petDao.getAllPets();
	}

	
	public List<Pet> getMyPets(int userId) {
		
		return petDao.getMyPets(userId);
	}


	public void savePet(Pet pets) {
		petDao.savePet(pets);
		
	}

	
	public User authenticateUser(String name, String passwd) {
		
		return petDao.authenticateUser(name, passwd);
	}

	
	public void buyPet(int petId, int userId) {
		petDao.buyPet(petId, userId);
		
	}
	
	

}
