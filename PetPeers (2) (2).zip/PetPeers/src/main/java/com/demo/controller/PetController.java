package com.demo.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.demo.model.Pet;
import com.demo.model.User;
import com.demo.service.PetService;

@RestController
public class PetController {
	
	public PetController(PetService petService) {
		this.petService=petService;
		
	}
	
	@Autowired
	PetService petService;
	
	@GetMapping("/")
	public ModelAndView index() {
		return new ModelAndView("Index");
	}

	@GetMapping("/login")
	public ModelAndView login(@ModelAttribute("user") User user) {
		return new ModelAndView("LoginPage");
	}

	@PostMapping("/authenticateUser")
	public ModelAndView authenticateUser(HttpServletRequest req, @ModelAttribute("user") User user) {
		req.getSession().setAttribute("user", user);
		String name = req.getParameter("userName");
		String passwd = req.getParameter("userPasswd");
		User users = petService.authenticateUser(name, passwd);
		if(users == null) {
			return new ModelAndView("InvalidUser");
		}else {
			req.getSession().setAttribute("id", users.getUserId());
			return new ModelAndView("HomePage", "pets", petService.getAllPets());
		}
	}

	@GetMapping("/register")
	public ModelAndView register(@ModelAttribute("user") User user) {
		return new ModelAndView("Registration");
	}

	@PostMapping("/save")
	public ModelAndView saveUser(@ModelAttribute("user") User user) {
		User userCheck = petService.saveUser(user);
		if(userCheck == null) {
			return new ModelAndView("Registration", "registered", "UserName already Taken!");
		}
		else
		{
			return new ModelAndView("LoginPage", "registered", "Registration Success");
		}	
	}

	@GetMapping("/home")
	public ModelAndView home(@ModelAttribute("user") User user) {

		return new ModelAndView("HomePage", "pets", petService.getAllPets()); 
	}

	@GetMapping("/buyPet")
	public ModelAndView buyPet(HttpServletRequest req) {
		
		int userid = (Integer) req.getSession().getAttribute("id");

		int petId = Integer.parseInt(req.getParameter("petId"));
		req.getSession().setAttribute("petId", petId);

		System.out.println(req.getParameter("petId"));
		petService.buyPet(petId, userid);
		return new ModelAndView("HomePage", "pets", petService.getAllPets()); 
	}

	@GetMapping("/addPet")
	public ModelAndView addPet() {

		return new ModelAndView("AddPet", "pet", new Pet()); 
	}

	@PostMapping("/savePet")
	public ModelAndView savePet(@ModelAttribute("pets") Pet pet) {
		petService.savePet(pet);
		return new ModelAndView("HomePage", "pets", petService.getAllPets()); 
	}

	@GetMapping("/myPets")
	public ModelAndView petList(HttpServletRequest req) {
		
		int userId = (Integer) req.getSession().getAttribute("id");
		return new ModelAndView("Mypet", "mypets", petService.getMyPets(userId));
		
	}

	@GetMapping("/logout")
	public ModelAndView logout(@ModelAttribute("user") User user) {

		return new ModelAndView("LoginPage");
	}

}
