package com.hibernateannotations.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;

import com.hibernateannotations.model.Student;

public class StudentMain {

	public static void main(String[] args) {
		Session session = new AnnotationConfiguration().configure("hibernate.cfg.xml").buildSessionFactory().openSession();
//Configuration cfg = new Configuration();
//cfg.configure("hibernate.cfg.xml");
//SessionFactory sessionFactory = cfg.buildSessionFactory();
//Session session = sessionFactory.openSession();
Transaction tx = session.beginTransaction();
Student std = new Student(12345,"Sowmya","Ramidi","IT","JBREC","Hyderabad");
session.save(std);
tx.commit();
System.out.println("Student details filled successfully");
	}

}
