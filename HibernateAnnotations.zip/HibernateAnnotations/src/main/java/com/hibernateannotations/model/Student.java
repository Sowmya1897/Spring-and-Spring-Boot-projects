package com.hibernateannotations.model;

import javax.persistence.*;

@Entity
@Table(name="Student")
public class Student {
@Id	
@GeneratedValue(strategy=GenerationType.AUTO)
private int id;
@Column(name="rollnumber")
private int rollnumber;
@Column(name="firstName")
private String firstName;
@Column(name="lastName")
private String lastName;
@Column(name="branch")
private String branch;
@Column(name="collegeName")
private String collegeName;
@Column(name="address")
private String address;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public int getRollnumber() {
	return rollnumber;
}
public void setRollnumber(int rollnumber) {
	this.rollnumber = rollnumber;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public String getBranch() {
	return branch;
}
public void setBranch(String branch) {
	this.branch = branch;
}
public String getCollegeName() {
	return collegeName;
}
public void setCollegeName(String collegeName) {
	this.collegeName = collegeName;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public Student(int rollnumber, String firstName, String lastName, String branch, String collegeName, String address) {
	super();
	this.rollnumber = rollnumber;
	this.firstName = firstName;
	this.lastName = lastName;
	this.branch = branch;
	this.collegeName = collegeName;
	this.address = address;
}
public Student() {
	super();
	// TODO Auto-generated constructor stub
}


}
