package com.mockito.main.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Account_tbl")
public class Account {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
private int accountId;
private double balance;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public int getAccountId() {
	return accountId;
}
public void setAccountId(int accountId) {
	this.accountId = accountId;
}
public double getBalance() {
	return balance;
}
public void setBalance(double balance) {
	this.balance = balance;
}
public Account(int accountId, double balance) {
	super();
	
	this.accountId = accountId;
	this.balance = balance;
}
public Account() {
	super();

}
@Override
public String toString() {
	return "Account [id=" + id + ", accountId=" + accountId + ", balance=" + balance + "]";
}


}


