package com.mockito.main.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mockito.main.model.Account;
import com.mockito.main.repository.AccountRepository;

@Service
public class AccountServiceImpl implements AccountServiceInterface{
@Autowired 
AccountRepository repository;
	public void save(Account account) {
		repository.save(account);
		
	}
	@Override
	public Account saveAccount(Account any) {
		repository.save(any);
		return any;
	}

}
