package com.mockito.main.service;

import com.mockito.main.model.Account;

public interface AccountServiceInterface {

	void save(Account account);

	Account saveAccount(Account any);

}
