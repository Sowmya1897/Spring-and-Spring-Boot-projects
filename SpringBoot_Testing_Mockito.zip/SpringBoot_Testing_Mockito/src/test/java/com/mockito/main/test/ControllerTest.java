package com.mockito.main.test;


import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mockito.main.controller.AccountController;
import com.mockito.main.model.Account;
import com.mockito.main.repository.AccountRepository;
import com.mockito.main.service.AccountServiceInterface;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ControllerTest {
	
@Autowired
WebApplicationContext context;

@Autowired
AccountController controller;
@Autowired
AccountRepository repository;
@MockBean
AccountServiceInterface service;

private MockMvc mvc;

@Before
public void setUp() {
MockitoAnnotations.initMocks(this);	
mvc=MockMvcBuilders.webAppContextSetup(context).build();
}

/*@Test
public void saveAccount() {
	
	Account account = new Account(178902,56780);
	Mockito.when(service.saveAccount(Mockito.any(Account.class))).thenReturn(account);
	try {
		mvc.perform(post("/v1/accounts/saveAccount")
				.contentType(MediaType.APPLICATION_JSON)
				.content(asJsonString(account)))
		.andExpect(status().isCreated());
	} catch (Exception e) {
		
		e.printStackTrace();
	}
}


public String asJsonString(Account obj) throws JsonProcessingException {
	ObjectMapper mapper = new ObjectMapper();
	
		return mapper.writeValueAsString(obj);

}*/

@Test
public void createAccount() throws Exception {
  this.mvc.perform(post("/v1/accounts/saveAccount")
		  .contentType(MediaType.APPLICATION_JSON)
    .content("{\"accountId\":\"123\",\"balance\":1000}"))
  .andExpect(status().isCreated());
}

}
