package com.mockito.main.test;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.mockito.main.model.Account;
import com.mockito.main.service.AccountServiceInterface;


@RunWith(SpringRunner.class)//JUnit annotations
@SpringBootTest
public class AccountServiceTest {
	@Autowired
	AccountServiceInterface accountService;

	@Test
	public void saveAccount() {
		Account account = new Account(1001, 34444);
		accountService.save(account);
	}
}
