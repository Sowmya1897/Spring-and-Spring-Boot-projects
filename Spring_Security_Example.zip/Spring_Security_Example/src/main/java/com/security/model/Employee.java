package com.security.model;

public class Employee {
private int empId;
private String empName;
private String empDept;
private String empLocation;
public int getEmpId() {
	return empId;
}
public void setEmpId(int empId) {
	this.empId = empId;
}
public String getEmpName() {
	return empName;
}
public void setEmpName(String empName) {
	this.empName = empName;
}
public String getEmpDept() {
	return empDept;
}
public void setEmpDept(String empDept) {
	empDept = empDept;
}
public String getEmpLocation() {
	return empLocation;
}
public void setEmpLocation(String empLocation) {
	this.empLocation = empLocation;
}
public Employee(int empId, String empName, String empDept, String empLocation) {
	super();
	this.empId = empId;
	this.empName = empName;
	empDept = empDept;
	this.empLocation = empLocation;
}
public Employee() {
	super();
	
}


}
