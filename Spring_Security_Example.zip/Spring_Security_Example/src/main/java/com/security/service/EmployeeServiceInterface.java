package com.security.service;

import java.util.List;


import com.security.model.Employee;

public interface EmployeeServiceInterface {

	List<Employee> findAll();

}
