package com.security.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.security.model.Employee;
@Service
public class EmployeeServiceImpl implements EmployeeServiceInterface {
	static List<Employee> empList = null;
	static {
		empList = new ArrayList<>();
		empList.add(new Employee(101,"employee1","dept1","location1"));
		empList.add(new Employee(102,"employee2","dept2","location2"));
		empList.add(new Employee(103,"employee3","dept3","location3"));
	}
	
	public List<Employee> findAll() {
	
		return empList;
	}

}
