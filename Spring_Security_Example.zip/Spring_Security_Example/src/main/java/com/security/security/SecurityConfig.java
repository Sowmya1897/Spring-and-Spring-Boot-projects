package com.security.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter
{
	@Bean
    public  PasswordEncoder passwordEncoder() {
       
         return (NoOpPasswordEncoder) NoOpPasswordEncoder.getInstance();
       
    }
	public void configure(AuthenticationManagerBuilder auth) {
        try {
            auth.inMemoryAuthentication().withUser("sowmya").password("password").roles("USER").and().withUser("admin")
                    .password("admin").roles("ADMIN");
        } catch (Exception e) {
            System.out.println(e);
        }
    }
public void configure(HttpSecurity http)
{
try {//csrf-cross origin request forgery
	http.authorizeRequests()
	    .antMatchers("/api/employees").hasRole("ADMIN")
	    .and()
	    .csrf().disable()
	    .formLogin().and().exceptionHandling().accessDeniedPage("/api/403");
} catch (Exception e) {
	
	e.printStackTrace();
}
}

}

