package com.onetomany.main;

import javax.persistence.*;

@Entity
@Table(name="Projects")
public class Projects {
	@Id
	@GeneratedValue(strategy=GenerationType.TABLE)
	@Column(name="pid")
	private int pid;
	@Column(name="ProjectName")
	private String projectName;
	
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	
	public Projects() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Projects [pid=" + pid + ", projectName=" + projectName + "]";
	}
	
	
}
