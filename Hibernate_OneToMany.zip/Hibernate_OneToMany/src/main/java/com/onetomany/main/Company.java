package com.onetomany.main;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

@Entity
@Table(name="Company")
public class Company {
	@Id
	@GeneratedValue(strategy=GenerationType.TABLE)
	@Column(name="cid")
private int cid;
	@Column(name="CompanyName")
private String companyName;
	 @OneToMany(cascade=CascadeType.ALL)
	 @JoinTable(
		name="Company_Projects", 
		joinColumns=@JoinColumn(name="comp_id", referencedColumnName="cid"
		),
		inverseJoinColumns=@JoinColumn(name="Proj_id", referencedColumnName="pid"
		)
	)
private List<Projects> projects = new ArrayList<>();
public int getCid() {
	return cid;
}
public void setCid(int cid) {
	this.cid = cid;
}
public String getCompanyName() {
	return companyName;
}
public void setCompanyName(String companyName) {
	this.companyName = companyName;
}

public List<Projects> getProjects() {
	return projects;
}
public void setProjects(List<Projects> projects) {
	this.projects = projects;
}

public Company() {
	super();
	// TODO Auto-generated constructor stub
}
@Override
public String toString() {
	return "Company [cid=" + cid + ", companyName=" + companyName + ", projects=" + projects + "]";
}


}
