package com.onetomany.main;

import java.util.ArrayList;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


public class OneToMany_Main1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sessionFactory = cfg.buildSessionFactory();
		Session session = sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		
		    Projects p1 = new Projects();
			p1.setProjectName("HealthCare");
			
			Projects p2 = new Projects();
			p2.setProjectName("BB Finance");
			
			Projects p3 = new Projects();
			p3.setProjectName("Uniliver Promotion Management");
			
			Projects p4 = new Projects();
			p4.setProjectName("Sales Performance Management");
			
			ArrayList<Projects> list1 = new ArrayList<Projects>();
			list1.add(p1);
			list1.add(p2);
			
			ArrayList<Projects> list2 = new ArrayList<Projects>();
			list2.add(p3);
			list2.add(p4);
			
		Company comp1 = new Company();
		comp1.setCompanyName("Hcl");
		comp1.setProjects(list1);
		
		Company comp2 = new Company();
		comp2.setCompanyName("Wipro");
		comp2.setProjects(list2);
		
		session.persist(comp1);
		session.persist(comp2);
		tx.commit();
		session.close();
		System.out.println("Company projects are filled successfully");
			}
	}


