package com.hcl.cs.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Projections;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hcl.cs.model.Pet;
import com.hcl.cs.model.PetUser;

@Repository
public class UserDAOImpl implements UserDAO {
	@Autowired
	SessionFactory sessionFactory;

	
	public void saveUser(PetUser user) {
	sessionFactory.openSession().save(user);
		
	}
	
	public void buyPet(long petId, PetUser user) {
		Session session = sessionFactory.getCurrentSession();
		Pet pet = (Pet) session.get(Pet.class,petId);
		pet.setPetOwner(user);
		session.update(pet);
		//logger.info(user.getUserName()+" entered in to buyPet method of UserDaoImpl");
		//logger.info(user.getUserName()+" bought a pet named "+pet.getName());
		
	}

	public List<Pet> getMyPets(PetUser user) {
		/*String sql="SELECT * FROM PETS WHERE OWNER_ID="+user.getUserId();//Native Query returns a Result Set
		   @SuppressWarnings("unchecked")
		List<Pet> list=sessionFactory.getCurrentSession().createSQLQuery(sql).addEntity(Pet.class).list();
	
			return list;*/
		/*Session session=(Session) sessionFactory.getCurrentSession().get(PetUser.class, 1);
		SQLQuery query = session.createSQLQuery("SELECT * FROM PETS WHERE OWNER_ID="+user.getUserId());
					
		List<Pet> list= query.list();
		return list;*/
		/*Criteria crt=sessionFactory.getCurrentSession().createCriteria(Pet.class); // here should be something else than list()
	    crt.setProjection(Projections.property("petOwner_userid"));
	    List<Pet> pets = crt.list();
	    return pets;*/
		Query query = sessionFactory.openSession().createQuery("from Pet");
		List<Pet>  list = query.list();
		return list;
	}


	





}
