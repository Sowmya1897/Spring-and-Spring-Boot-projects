package com.hcl.cs.model;

import java.io.Serializable;

import javax.persistence.*;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="Pet_User")
public class Pet implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="petId")
	private Long petId;
	@NotEmpty(message="PetName should not be emplty")
	@Column(name="petName")
	private String petName;
	@NotEmpty(message="Age should be 0 and 99 years")
	@Column(name="petAge")
	private String petAge;
	@NotEmpty(message="PetPlace should not be emplty")
	@Column(name="petPlace")
	private String petPlace;
	@ManyToOne
	private PetUser petOwner;
	
	public Long getPetId() {
		return petId;
	}

	public void setPetId(Long petId) {
		this.petId = petId;
	}

	public String getPetName() {
		return petName;
	}

	public void setPetName(String petName) {
		this.petName = petName;
	}

	public String getPetAge() {
		return petAge;
	}

	public void setPetAge(String petAge) {
		this.petAge = petAge;
	}

	public String getPetPlace() {
		return petPlace;
	}

	public void setPetPlace(String petPlace) {
		this.petPlace = petPlace;
	}

	public PetUser getPetOwner() {
		return petOwner;
	}

	public void setPetOwner(PetUser petOwner) {
		this.petOwner = petOwner;
	}

	

	public Pet(Long petId, String petName, String petAge, String petPlace, PetUser petOwner) {
		super();
		this.petId = petId;
		this.petName = petName;
		this.petAge = petAge;
		this.petPlace = petPlace;
		this.petOwner = petOwner;
	}

	public Pet() {
		super();
		
	}

	@Override
	public String toString() {
		return "Pet [petId=" + petId + ", petName=" + petName + ", petAge=" + petAge + ", petPlace=" + petPlace
				+ ", petOwner=" + petOwner + "]";
	}

	
	
}
