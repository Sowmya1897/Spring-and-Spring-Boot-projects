package com.hcl.cs.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hcl.cs.model.Pet;
import com.hcl.cs.model.PetUser;

@Repository
public class PetDAOImpl implements PetDAO {
	@Autowired
	SessionFactory sessionFactory;

	public void savePet(Pet pet) {
	sessionFactory.openSession().save(pet);
		
	}
	public List<Pet> getMyPets() {
		Query query = sessionFactory.openSession().createQuery("from Pet");
		List<Pet>  list = query.list();
		return list;
	}
	
	public List<Pet> getAllPets() {
		Query query = sessionFactory.openSession().createQuery("from Pet");
		List<Pet>  list = query.list();
		return list;
	}
	@Override
	public Pet getPetById(Long petId) {
		Query query= sessionFactory.getCurrentSession().
		        createQuery("from PetUser where petid=:id");
		Pet pet = (Pet) query.uniqueResult();
		return pet;
	}


}
