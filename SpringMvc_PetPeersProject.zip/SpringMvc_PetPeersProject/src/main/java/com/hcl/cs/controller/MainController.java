package com.hcl.cs.controller;

import java.util.Base64;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.hcl.cs.model.Pet;
import com.hcl.cs.model.PetUser;
import com.hcl.cs.service.PetService;
import com.hcl.cs.service.UserService;
import com.hcl.cs.validator.UserValidator;

@Controller
public class MainController {
	@Autowired
	PetService petService;
	@Autowired
	UserService userService;
	
	UserValidator userValidator;
	//private static final Logger logger = LogManager.getLogger(MainController.class);

	@InitBinder
	   protected void initBinder(WebDataBinder binder) {
	      binder.addValidators(userValidator);
	   }
	@RequestMapping("/")
	public ModelAndView index()
	{
		
		return new ModelAndView("index");
	}
	@RequestMapping("/login")
	public ModelAndView login(@ModelAttribute("user") PetUser user)
	{
		
		return new ModelAndView("loginPage");
	}
	
	@RequestMapping("/signup")
	public ModelAndView register(@ModelAttribute("user") PetUser user)
	{
		
		return new ModelAndView("registrationPage");
	}
	
	@RequestMapping("/saveUser")
	public ModelAndView saveUser(@Validated @ModelAttribute("user") PetUser user, BindingResult result)
	{

		ModelAndView mav = null;
		String name="";
		if(result.hasErrors())
		{ 
		
			return new ModelAndView("registrationPage");
		}
		 
		userService.saveUser(user);
		
		if(null!=user)
		{
		
		           if(!name.equals(user.getUserName()))
		           {
			           mav= new ModelAndView("loginPage");
			           mav.addObject("message","You are successfully registered. Please login now");
		            }else
		            {
			           mav = new ModelAndView("registrationPage");
			            mav.addObject("message", "User Name already in use. Please select a different User Name");
		            }
		}      
		else {
			mav = new ModelAndView("registrationPage");
		}
	
		
		return mav;	
	}
	
	@RequestMapping("/authenticateUser")
	public ModelAndView authenticateUser(HttpServletRequest request, @ModelAttribute("user") PetUser user, BindingResult result)
	{
		if(result.hasErrors())
		{
			return new ModelAndView("loginPage");
		}
		//userService.authenticateUser(user);
		List<Pet> pets = petService.getAllPets();
		return new ModelAndView("homePage","PetDetails", pets);
	}
	@RequestMapping("/home")
	public ModelAndView home(@ModelAttribute("pet") Pet pet)
	{
		
		return new ModelAndView("homePage");
	}
		
	@RequestMapping("/addPet")
	public ModelAndView addPet(@ModelAttribute("pet") Pet pet)
	{
		
		return new ModelAndView("addPetPage");
	}
	
	@RequestMapping("/savePet")
	public ModelAndView savePet(@Validated @ModelAttribute("pet") Pet pet, BindingResult result) {
		if(result.hasErrors())
		{ 
		
			return new ModelAndView("addPetPage");
		}
	    petService.savePet(pet);
		return new ModelAndView("redirect:/fetchPets");
	}
	@RequestMapping("fetchPets")
	public ModelAndView home() {
		List<Pet> pets = petService.getAllPets();
		return new ModelAndView("homePage", "PetDetails", pets);
	}
	/*@RequestMapping("/myPets")
	public ModelAndView myPets(@ModelAttribute("pet") Pet pet)
	{
	
		return new ModelAndView("myPetsPage");
	}*/
	/*
	@RequestMapping("buyPet/{id}")
	public ModelAndView buyPet(@ModelAttribute("pet") Pet pet, @PathVariable Long id) {
		PetUser ur = userService.saveMyPet(id);
		return new ModelAndView("redirect:/myPets");
	}
	@RequestMapping("myPets")
	public ModelAndView myAllPets(@ModelAttribute("pet") Pet pet) {
		List<Pet> pets =userService.getMyPets(pet);
		return new ModelAndView("myPetsPage", "PetsDetails", pets);
	}*/
	
	@RequestMapping("buyPet/{petId}")
    public ModelAndView buyPet(@ModelAttribute("pet") Pet pet,@PathVariable("petId") long petId, HttpServletRequest request) {
        PetUser user = (PetUser) request.getSession().getAttribute("user");	

        	userService.buyPet(petId, user);
          
            return new ModelAndView("redirect:/myPets");
	}
        @RequestMapping("myPets")
    	public ModelAndView myPets(HttpServletRequest request) {
    		PetUser user = (PetUser) request.getSession().getAttribute("user");

    			List<Pet> pets = userService.getMyPets(user);
    			
    				return new ModelAndView("myPetsPage", "PetsDetails", pets);
    		
    		}

	@RequestMapping("/logout")
	public ModelAndView logout() {
		return new ModelAndView("redirect:/login");
	}
}
