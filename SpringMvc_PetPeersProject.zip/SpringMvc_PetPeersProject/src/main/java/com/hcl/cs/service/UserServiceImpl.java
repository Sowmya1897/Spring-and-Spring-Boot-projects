package com.hcl.cs.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hcl.cs.dao.UserDAO;
import com.hcl.cs.model.Pet;
import com.hcl.cs.model.PetUser;

@Service
public class UserServiceImpl implements UserService {
@Autowired
UserDAO userDao;
@Autowired
private PasswordEncoder passwordEncoder;

public void saveUser(PetUser user) {
	user.setUserPassword(passwordEncoder.encode(user.getUserPassword()));
	user.setConfirmPassword(passwordEncoder.encode(user.getConfirmPassword()));
	userDao.saveUser(user);
	
}

@Transactional
public List<Pet> getMyPets(PetUser user) {
	return userDao.getMyPets(user);
}

@Transactional
public void buyPet(long petId, PetUser user) {
	userDao.buyPet(petId, user);

}


}	
	


