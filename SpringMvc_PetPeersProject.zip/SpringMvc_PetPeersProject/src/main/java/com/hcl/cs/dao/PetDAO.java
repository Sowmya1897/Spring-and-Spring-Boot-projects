package com.hcl.cs.dao;

import java.util.List;

import com.hcl.cs.model.Pet;

public interface PetDAO {

	void savePet(Pet pet);

	List<Pet> getMyPets();

	List<Pet> getAllPets();

	Pet getPetById(Long petId);


}
