package com.hcl.cs.dao;

import java.util.List;

import com.hcl.cs.model.Pet;
import com.hcl.cs.model.PetUser;

public interface UserDAO {

	void saveUser(PetUser user);

	List<Pet> getMyPets(PetUser user);

	void buyPet(long petId, PetUser user);

}
