package com.hcl.cs.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.*;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="user_tbl")
public class PetUser implements Serializable {
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
@Column(name="userId")
private Long userId;
@NotEmpty(message="UserName should not be empty")
@Column(name="userName")
private String userName;
@NotEmpty(message="Password should not be empty")
@Column(name="userPassword")
private String userPassword;
@NotEmpty(message="Confirm Password should not be empty")
@Column(name="confirmPassword")
private String confirmPassword;
@OneToMany
@JoinColumn(name="petOwnerId")
private Set<Pet> pets = new HashSet<>();
public Long getUserId() {
	return userId;
}

public void setUserId(Long userId) {
	this.userId = userId;
}

public String getUserName() {
	return userName;
}

public void setUserName(String userName) {
	this.userName = userName;
}

public String getUserPassword() {
	return userPassword;
}

public void setUserPassword(String userPassword) {
	this.userPassword = userPassword;
}

public String getConfirmPassword() {
	return confirmPassword;
}

public void setConfirmPassword(String confirmPassword) {
	this.confirmPassword = confirmPassword;
}

public Set<Pet> getPets() {
	return pets;
}

public void setPets(Set<Pet> pets) {
	this.pets = pets;
}

public PetUser() {
	super();
}

public PetUser(Long userId, String userName, String userPassword, String confirmPassword, Set<Pet> pets) {
	super();
	this.userId = userId;
	this.userName = userName;
	this.userPassword = userPassword;
	this.confirmPassword = confirmPassword;
	this.pets = pets;
}

@Override
public String toString() {
	return "PetUser [userId=" + userId + ", userName=" + userName + ", userPassword=" + userPassword
			+ ", confirmPassword=" + confirmPassword + ", pets=" + pets + "]";
}


}
