package com.hcl.cs.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.cs.dao.PetDAO;
import com.hcl.cs.model.Pet;

@Service
public class PetServiceImpl implements PetService {
@Autowired
PetDAO petDao;

public void savePet(Pet pet) {
	petDao.savePet(pet);
	
}

public List<Pet> getMyPets() {
	return petDao.getMyPets();
}

public List<Pet> getAllPets() {
	return petDao.getAllPets();
}


}
