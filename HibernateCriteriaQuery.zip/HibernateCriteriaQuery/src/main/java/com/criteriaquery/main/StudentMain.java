package com.criteriaquery.main;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;

import com.criteriaquery.model.Student;

public class StudentMain {
	public static void main(String[] args) {
	
Configuration cfg = new Configuration();
cfg.configure("hibernate.cfg.xml");
SessionFactory sessionFactory = cfg.buildSessionFactory();
Session session = sessionFactory.openSession();
//Transaction tx = session.beginTransaction();
//Student std = new Student(16789,"Sravanthi","Ramidi","CSE","MLRIT","Hyderabad");
//session.save(std);
//tx.commit();

Query query = session.getNamedQuery("findStudentByName");
query.setParameter("firstName", "Sowmya");
List<Student> list = query.list();
list.forEach(stu -> System.out.println(stu));
System.out.println("Student details filled successfully");
	}

}
