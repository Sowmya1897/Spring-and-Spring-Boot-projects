package com.criteriaquery.main;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.criteriaquery.model.Employee;

public class EmployeeMain {
	public static void main(String[] args) {
	Configuration cfg = new Configuration();
	cfg.configure("hibernate.cfg.xml");
	SessionFactory sessionFactory = cfg.buildSessionFactory();
	Session session = sessionFactory.openSession();
	/*Transaction tx = session.beginTransaction();
	Employee employee = new Employee("Priya","Apex","DataAnalyst");
	session.save(employee);
	tx.commit();
*/
	Query query = session.getNamedQuery("findEmployeeByName");
	query.setParameter("name", "Sowmya");
	List<Employee> list = query.list();
	list.forEach(emp -> System.out.println(emp));
	System.out.println("Employee details filled successfully");
		}
}

