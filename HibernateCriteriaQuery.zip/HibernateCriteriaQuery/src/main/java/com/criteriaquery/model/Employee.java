package com.criteriaquery.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.Table;
@NamedNativeQueries(
{
@NamedNativeQuery(name="findEmployeeByName",query="select * from Employee_Details where empName=:name",resultClass=Employee.class)
}
)
@Entity
@Table(name="Employee_Details")
public class Employee {
	@Id	
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int eid;
	@Column(name="empName")
	private String empName;
	@Column(name="CompanyName")
	private String companyName;
	@Column(name="Designation")
	private String designation;
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public Employee(String empName, String companyName, String designation) {
		super();
		this.empName = empName;
		this.companyName = companyName;
		this.designation = designation;
	}
	public Employee() {
		super();
		
	}
	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", empName=" + empName + ", companyName=" + companyName + ", designation="
				+ designation + "]";
	}
	
}
