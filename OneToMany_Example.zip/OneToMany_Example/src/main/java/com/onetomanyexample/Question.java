package com.onetomanyexample;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="Question")
public class Question {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="qid")
private int qid;
	@Column(name="questionName")
private String questionName;
	@OneToMany(cascade=CascadeType.ALL)
	//@JoinColumn(name="ques_id")
	@JoinTable(
            name = "Question_Answer",
            joinColumns = @JoinColumn(name = "Questin_id"),
            inverseJoinColumns = @JoinColumn(name = "Answer_Id")
    )
	private List<Answers> answers = new ArrayList<Answers>();
	public int getQid() {
		return qid;
	}
	public void setQid(int qid) {
		this.qid = qid;
	}
	public String getQuestionName() {
		return questionName;
	}
	public void setQuestionName(String questionName) {
		this.questionName =questionName;
	}
	
	public List<Answers> getAnswers() {
		return answers;
	}
	public void setAnswers(List<Answers> answers) {
		this.answers = answers;
	}
	
	public Question() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Question [qid=" + qid + ", questionName=" + questionName + ", answers=" + answers + "]";
	}
	
	
	
}
