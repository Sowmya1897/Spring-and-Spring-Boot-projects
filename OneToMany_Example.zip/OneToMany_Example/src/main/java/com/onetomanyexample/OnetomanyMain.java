package com.onetomanyexample;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

public class OnetomanyMain {

	public static void main(String[] args) {
		
		Session session = new AnnotationConfiguration().configure("hibernate.cfg.xml").buildSessionFactory().openSession();
Transaction tx = session.beginTransaction();

Question qsn = new Question();
qsn.setQuestionName("What is Java?");

Answers ans1  = new Answers();
ans1.setAnswerName("Java is a Programming Language");
ans1.setPostedBy("Sowmya");

Answers ans2  = new Answers();
ans2.setAnswerName("It is Object Oriented Language");
ans2.setPostedBy("Sam");

List<Answers> list = new ArrayList<>();
list.add(ans1);
list.add(ans2);

qsn.setAnswers(list);

session.save(qsn);
tx.commit();
System.out.println("Success");
	}

}
