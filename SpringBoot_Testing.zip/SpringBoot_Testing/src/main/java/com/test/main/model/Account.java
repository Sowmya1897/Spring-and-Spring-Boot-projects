package com.test.main.model;

import javax.persistence.*;


@Entity
@Table(name="test_account")
public class Account {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
private int accountId;
private double balance;
public int getAccountId() {
	return accountId;
}
public void setAccountId(int accountId) {
	this.accountId = accountId;
}
public double getBalance() {
	return balance;
}
public void setBalance(double balance) {
	this.balance = balance;
}
public Account(int accountId, double balance) {
	super();
	this.accountId = accountId;
	this.balance = balance;
}
public Account() {
	super();
	
}

}
