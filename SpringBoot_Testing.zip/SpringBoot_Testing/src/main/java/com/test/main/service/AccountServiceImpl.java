package com.test.main.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.test.main.model.Account;
import com.test.main.repository.AccountRepository;

@Service
public class AccountServiceImpl implements AccountServiceInterface{
@Autowired
AccountRepository repository;

@Override
public void save(Account account) {
	repository.save(account);	
}


}
