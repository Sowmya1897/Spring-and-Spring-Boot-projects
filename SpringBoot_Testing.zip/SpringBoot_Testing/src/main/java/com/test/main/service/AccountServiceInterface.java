package com.test.main.service;

import com.test.main.model.Account;

public interface AccountServiceInterface {

	void save(Account account);

}
