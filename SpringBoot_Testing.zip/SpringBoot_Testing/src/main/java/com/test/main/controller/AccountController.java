package com.test.main.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.test.main.model.Account;
import com.test.main.service.AccountServiceInterface;

@RestController
@RequestMapping("/v1/accounts")
public class AccountController {
@Autowired
AccountServiceInterface accountService;

@PostMapping("/saveAccount")
public ResponseEntity<String> saveAccounts(@RequestBody Account account){
	accountService.save(account);
	return new ResponseEntity<String>("Account details saved successfully", HttpStatus.CREATED);
}
}
