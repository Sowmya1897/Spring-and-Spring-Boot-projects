package com.configuration.main;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.configuration.main.model.AppProperties;

@SpringBootApplication
public class SpringbootConfigurationApplication implements CommandLineRunner{
	
	Logger logger =LoggerFactory.getLogger(SpringbootConfigurationApplication.class);
	
	@Autowired
	AppProperties properties;
	
	public static void main(String[] args) {
		SpringApplication.run(SpringbootConfigurationApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {//varargs
	logger.info(properties.getColor());
	logger.info(properties.getLang());
	logger.info(properties.getTheme());
	}
}
