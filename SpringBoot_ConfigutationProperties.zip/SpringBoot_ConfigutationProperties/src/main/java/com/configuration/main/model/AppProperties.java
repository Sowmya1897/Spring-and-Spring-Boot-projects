package com.configuration.main.model;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
@Configuration
@ConfigurationProperties(prefix="app")
public class AppProperties {

private int id;
private String color;
private String lang;
private String theme;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getColor() {
	return color;
}
public void setColor(String color) {
	this.color = color;
}
public String getLang() {
	return lang;
}
public void setLang(String lang) {
	this.lang = lang;
}
public String getTheme() {
	return theme;
}
public void setTheme(String theme) {
	this.theme = theme;
}
public AppProperties(int id, String color, String lang, String theme) {
	super();
	this.id = id;
	this.color = color;
	this.lang = lang;
	this.theme = theme;
}
public AppProperties() {
	super();

}


}
