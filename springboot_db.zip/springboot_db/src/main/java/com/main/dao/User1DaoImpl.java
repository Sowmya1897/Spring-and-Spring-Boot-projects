package com.main.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.main.model.User1;


@Repository
public class User1DaoImpl implements User1DaoInterface{
	@Autowired
	SessionFactory sessionFactory;
	
	public void saveUserDetails(User1 user) {
		sessionFactory.openSession().save(user);
		
	}

	
	public List<User1> getUserDetails() {
		Query query = sessionFactory.openSession().createQuery("from User1");
		List<User1> list = query.list();
		return list;
	}


	public void deleteUser(String name) {
		/*Query q = ((Session) sessionFactory).createQuery("delete User1 where id ="+id);
		//sessionFactory.openSession().delete(id);
		User1 ur = new User1();
	    ur.setId(id);
	    Criteria query = sessionFactory.openSession().createCriteria("delete User1 where id =:id");
		sessionFactory.getSessionFactoryOptions();
		String hql = "delete from User1 where id= :id"; 
		((Session) sessionFactory).createQuery(hql).setString("id", new Integer(id)).executeUpdate();*/
	Query query = (Query) sessionFactory.getCurrentSession().createQuery("delete from User1 where userName="+name);
	query.executeUpdate();
	}


}
