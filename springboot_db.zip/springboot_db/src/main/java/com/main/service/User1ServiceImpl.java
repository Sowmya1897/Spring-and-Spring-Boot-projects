package com.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.main.dao.User1DaoInterface;
import com.main.model.User1;



@Service
public class User1ServiceImpl implements User1ServiceInterface{
	@Autowired
	User1DaoInterface userDaoIntr;
	
	public void saveUserDetails(User1 user) {
		userDaoIntr.saveUserDetails(user);
		
	}

	
	public List<User1> getUserDetails() {
		
		return  userDaoIntr.getUserDetails();
	}


	public void deleteUser(String name) {
		userDaoIntr.deleteUser(name);
		
	}
}
