package com.main.service;

import java.util.List;

import com.main.model.User1;



public interface User1ServiceInterface {
	void saveUserDetails(User1 user);

	List<User1> getUserDetails();

	void deleteUser(String name);
}
