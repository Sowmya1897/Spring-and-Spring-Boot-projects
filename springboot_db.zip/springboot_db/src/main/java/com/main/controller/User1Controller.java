package com.main.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.main.model.User1;

import com.main.service.User1ServiceInterface;

@RestController
public class User1Controller {
	@Autowired
	User1ServiceInterface userServiceIntr;
@RequestMapping("/loadUserPage")
public ModelAndView loadLoginPage(@ModelAttribute("user") User1 user)
{
	
	return new ModelAndView("User1");
}
@RequestMapping("/nextPage")
public ModelAndView nextPage(@Validated @ModelAttribute("user") User1 user,Model model,BindingResult result)
{
	if(result.hasErrors())
	{
		return new ModelAndView("User1");
	}
	userServiceIntr.saveUserDetails(user);
	return new ModelAndView("redirect:/fetchUserDetails");	
}

public List<String> createLanguagesList(){
	List<String> languagesList = new ArrayList<String>();
	languagesList.add("English");
	languagesList.add("Hindi");
	languagesList.add("Other");
	return languagesList;
}

@RequestMapping("fetchUserDetails")
public ModelAndView fetchUserDetails(){
	List<User1> list = userServiceIntr.getUserDetails();
	return new ModelAndView("Success","UserDetails", list);
	
}
@RequestMapping(value="/deleteuser/{name}")    
public ModelAndView delete(@PathVariable String name){    
	userServiceIntr.deleteUser(name);    
    return new ModelAndView ("redirect:/fetchUserDetails");    
}     
}
