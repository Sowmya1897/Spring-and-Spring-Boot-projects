package com.springmvc.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.springmvc.model.Login;

@Repository
public class LoginDaoImpl implements LoginDaoInterface {
@Autowired
SessionFactory sessionFactory;
	
	public void saveLoginDetails(Login login) {
		sessionFactory.openSession().save(login);
		
	}

}
