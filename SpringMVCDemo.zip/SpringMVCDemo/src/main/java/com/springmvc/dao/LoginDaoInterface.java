package com.springmvc.dao;

import com.springmvc.model.Login;

public interface LoginDaoInterface {

	void saveLoginDetails(Login login);

}
