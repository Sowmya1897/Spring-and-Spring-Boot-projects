package com.springmvc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.springmvc.model.Login;
import com.springmvc.service.LoginServiceInterface;

@Controller
public class SpringMvcController {
	@Autowired
	LoginServiceInterface loginServiceIntrf;
@RequestMapping(path="/LoginPage")
public ModelAndView loginPage(@ModelAttribute("login") Login login) {
	return new ModelAndView("login");
}

@RequestMapping(path="/welcomePage")
public ModelAndView welcomePage(@Validated @ModelAttribute("login") Login login,Model model, BindingResult result) {
	if(result.hasErrors()) {
		return new ModelAndView("login");
	}
	loginServiceIntrf.saveLoginDetails(login);
	//model.addAttribute("userName",login.getUserName());
	//model.addAttribute("password",login.getPassword());
	//model.addAttribute("gender",login.getGender());
	return new ModelAndView("Success");
}
}
