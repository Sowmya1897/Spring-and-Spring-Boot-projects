package com.springmvc.service;

import com.springmvc.model.Login;

public interface LoginServiceInterface {

	void saveLoginDetails(Login login);

}
