package com.springmvc.service;


import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springmvc.dao.LoginDaoInterface;
import com.springmvc.model.Login;

@Service
@Transactional
public class LoginServiceImpl implements LoginServiceInterface{
@Autowired
	LoginDaoInterface loginDaoIntr;
	public void saveLoginDetails(Login login) {
		loginDaoIntr.saveLoginDetails(login);
		
	}

}
