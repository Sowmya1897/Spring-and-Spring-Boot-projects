package com.springmvc.model;

import javax.persistence.*;

import org.hibernate.validator.constraints.NotEmpty;
@Entity
@Table(name="Login")
public class Login {
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private int id;
	@NotEmpty(message="UserName should not be empty")
private String userName;
	@NotEmpty(message="Password should not be empty")
private String password;
	@NotEmpty(message="gender should not be empty")
	private String gender;
	
	
public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
public String getUserName() {
	return userName;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public void setUserName(String userName) {
	this.userName = userName;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}


}
