package com.springmvcform.service;

import java.util.List;

import com.springmvcform.model.User;

public interface UserServiceInterface {

	void saveUserDetails(User user);

	List<User> getUserDetails();
}
