package com.springmvcform.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springmvcform.dao.UserDaoInterface;
import com.springmvcform.model.User;



@Service
public class UserServiceImpl implements UserServiceInterface {
	@Autowired
	UserDaoInterface userDaoIntr;
	
	public void saveUserDetails(User user) {
		userDaoIntr.saveUserDetails(user);
		
	}

	
	public List<User> getUserDetails() {
		
		return  userDaoIntr.getUserDetails();
	}
}
