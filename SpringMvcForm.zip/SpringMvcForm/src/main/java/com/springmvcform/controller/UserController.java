package com.springmvcform.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.springmvcform.model.User;
import com.springmvcform.service.UserServiceInterface;

@Controller
public class UserController {
	@Autowired
	UserServiceInterface userServiceIntr;
@RequestMapping("/loadUserPage")
public ModelAndView loadLoginPage(@ModelAttribute("user") User user)
{
	
	return new ModelAndView("User");
}
@RequestMapping("/nextPage")
public ModelAndView nextPage(@Validated @ModelAttribute("user") User user,BindingResult result)
{
	if(result.hasErrors())
	{
		return new ModelAndView("User");
	}
	userServiceIntr.saveUserDetails(user);
	return new ModelAndView("redirect:/fetchUserDetails");	
}

public List<String> createLanguagesList(){
	List<String> languagesList = new ArrayList<String>();
	languagesList.add("English");
	languagesList.add("Hindi");
	languagesList.add("Other");
	return languagesList;
}

@RequestMapping("fetchUserDetails")
public ModelAndView fetchUserDetails(){
	List<User> list = userServiceIntr.getUserDetails();
	return new ModelAndView("Success","UserDetails", list);
	
}
}
