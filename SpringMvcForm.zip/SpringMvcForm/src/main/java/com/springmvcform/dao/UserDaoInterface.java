package com.springmvcform.dao;

import java.util.List;

import com.springmvcform.model.User;

public interface UserDaoInterface {

	void saveUserDetails(User user);

	List<User> getUserDetails();
}
