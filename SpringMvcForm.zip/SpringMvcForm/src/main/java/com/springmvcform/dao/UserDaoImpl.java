package com.springmvcform.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.springmvcform.model.User;

@Repository
public class UserDaoImpl implements UserDaoInterface{
	@Autowired
	SessionFactory sessionFactory;
	
	public void saveUserDetails(User user) {
		sessionFactory.openSession().save(user);
		
	}

	
	public List<User> getUserDetails() {
		Query query = sessionFactory.openSession().createQuery("from User");
		List<User> list = query.list();
		return list;
	}
}
